#!/bin/bash
cd -- "$(dirname -- "$0")" || exit 1
export PATH="$PATH:/opt/homebrew/bin:/usr/local/bin:$HOME/Library/Android/sdk/platform-tools:$HOME/Downloads/platform-tools:$HOME/platform-tools"
if [ -n "${ANDROID_HOME:-}" ]; then PATH="$PATH:$ANDROID_HOME/platform-tools"; fi
if [ -n "${ANDROID_SDK_ROOT:-}" ]; then PATH="$PATH:$ANDROID_SDK_ROOT/platform-tools"; fi
finish() {
    if [ -t 0 ]; then printf '\n按回车键关闭。'; read -r _; fi
    exit "$1"
}
if ! command -v adb >/dev/null; then
    printf '%s\n' '缺少 adb。请在 Mac 终端运行 brew install --cask android-platform-tools，完成后重新打开本文件。' '也可从 Android 官网下载 Mac 的 SDK Platform Tools，解压到 Mac 的“下载”文件夹。'
    finish 1
fi
if ! command -v python3 >/dev/null || ! python3 -V >/dev/null 2>&1; then
    printf '%s\n' '请先安装 Python 3，再重新打开本文件。使用 Homebrew 时可以运行 brew install python。'
    finish 1
fi
printf '%s\n' '请用 USB 数据线连接平板，打开 USB 调试，在平板上允许这台 Mac 调试。' '将把旧 App 已完成的下载复制到平板的 Download/NiceVideos 文件夹。'
if [ -t 0 ]; then printf '准备好后按回车键开始。'; read -r _; fi
python3 ./export_classic.py "$@"
finish "$?"
